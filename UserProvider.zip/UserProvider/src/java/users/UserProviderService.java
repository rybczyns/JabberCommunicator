package users;

import db.ChatDB;
import java.util.List;
import javax.ejb.Stateful;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;


@WebService(serviceName = "UserProviderService")
public class UserProviderService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getUsers")
    public String getUsers() {
        //TODO write your implementation code here:
        List<String> users = new ChatDB().getUsers();
        String result = "";
        for(String el : users){
            result += el +";";
        }
        return result;
        
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getPublicRooms")
    public String getPublicRooms() {
        //TODO write your implementation code here:
      
        List<String> users = new ChatDB().getRooms();
        String result = "";
        for(String el : users){
            result += el +";";
        }
        return result;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "sendMessage")
    public String sendMessage(String user, String room, String message) {
        
        ChatDB chatDao = new ChatDB();
        chatDao.addConversation(user, room, message);
        return null;
    }
}