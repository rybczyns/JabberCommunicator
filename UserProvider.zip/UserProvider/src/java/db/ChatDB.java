package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateful;


@Stateful
public class ChatDB {
    private static Connection connection;
    
    private static String address ="jdbc:mysql://localhost:3307/chat"; //url do polaczenia mysql.
    
    private static Connection getConnection(){
        if(connection == null){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                 connection=DriverManager.getConnection(address,"root","usbw");
            }
            catch(Exception ex){
                String info = "";
            }
        }
        return connection;
    }
    
    public ChatDB(){
        
    }
    
    public List<String> getUsers(){
        List<String> result = new ArrayList<String>();
        try{
        String sql = "select name from user";
        Statement stmt = null;
         stmt = getConnection().createStatement();
         
        ResultSet rs = stmt.executeQuery(sql);
        
        
         while (rs.next()) {
             String id = rs.getString("name");
             result.add(id);
         }
         
        }
        catch(Exception ex){
            String log = "";
        }
        return result;
    }
    
    public List<String> getRooms(){
        List<String> result = new ArrayList<String>();
        try{
        String sql = "select name from room";
        Statement stmt = null;
         stmt = getConnection().createStatement();
         
        ResultSet rs = stmt.executeQuery(sql);
        
         while (rs.next()) {
             String id = rs.getString("name");
             result.add(id);
         }
         
        }
        catch(Exception ex){
            String log = "";
        }
        return result;
    }
    
    public Integer getUserID(String userId){
        try{
        String sql = "select idUser from user where name = '" + userId + "'";
        Statement stmt = null;
         stmt = getConnection().createStatement();
         
        ResultSet rs = stmt.executeQuery(sql);
         while (rs.next()) {
             Integer id = rs.getInt("idUser");
             return id;
         }
         
        }
        catch(Exception ex){
            String log = "";
        }
        return null;
    }
    
    public Integer getRoomId(String room){
         try{
        String sql = "select idRoom from room where name = '" + room + "'";
        Statement stmt = null;
         stmt = getConnection().createStatement();
         
        ResultSet rs = stmt.executeQuery(sql);
         while (rs.next()) {
             Integer id = rs.getInt("idRoom");
             return id;
         }
         
        }
        catch(Exception ex){
            String log = "";
        }
        return null;
    }
    
   public void addConversation(String user, String room, String message){
    try{
        String tmpUserName = user.replace("/Smack", "");
        Integer idUser = getUserID(tmpUserName);
        Integer idRoom = getRoomId(room);
        String sql = "INSERT INTO MESSAGE(idUser,idRoom, message) VALUES (?,?,?)";
       
        PreparedStatement stmt = null;
        stmt = getConnection().prepareStatement(sql);
        
        stmt.setInt(1, idUser);
        stmt.setInt(2, idRoom);
        stmt.setString(3, message);
        stmt.executeUpdate();
       }
       catch(Exception ex){
           
       }
   }
}