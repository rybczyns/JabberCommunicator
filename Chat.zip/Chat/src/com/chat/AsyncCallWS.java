package com.chat;

import java.util.List;

import android.os.AsyncTask;

import com.chat.jabber.UserAndGroupsProvider;
import com.chat.webservice.UsersWebService;

public class AsyncCallWS extends AsyncTask<Void, Void, Void> {
    @Override
    protected Void doInBackground(Void... params) {
    	List<String> users = new UsersWebService().getUsers();
    	List<String> groups = new UsersWebService().getRooms();
    	
    	UserAndGroupsProvider.users = users;
    	UserAndGroupsProvider.groups = groups;
        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
    }

    @Override
    protected void onPreExecute() {
    }

    @Override
    protected void onProgressUpdate(Void... values) {
    }

}
