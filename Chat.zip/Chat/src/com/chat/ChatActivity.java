package com.chat;

import java.util.List;

import org.jivesoftware.smack.Connection;

import com.chat.jabber.ChatEntry;
import com.chat.jabber.ChatListener;
import com.chat.jabber.ChatSender;
import com.chat.jabber.ChatSenderGroup;
import com.chat.jabber.ChatSenderUser;
import com.chat.jabber.ConnectionProvider;
import com.chat.jabber.UserAndGroupsProvider;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ChatActivity extends Activity{
	private String userId;
	private boolean isGroupSelected;
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userId = "client3@vysper.org";
        setContentView(R.layout.activity_mainwindow);
       
        Button button =  (Button )findViewById(R.id.sendMessageButton);
        
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	String message = ((TextView)findViewById(R.id.messageText)).getText().toString();
            	String to = userId;
            	
            	
            	//ChatSender sender =ChatListener.isGroupChatSelected ? new ChatSenderGroup() : new ChatSenderUser();
            	//sender.sendMessage(to, message);
            	new WSMessageThread(to,message).start();
            	
            	((Button )findViewById(R.id.sendMessageButton)).setText("");
            }
        });
        
        Button buttonUsers = (Button)findViewById(R.id.users);
        buttonUsers.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	Intent i = new Intent(getApplicationContext(),UserListActivity.class);
            	startActivityForResult(i, 100);
            }
        });
        
        runOnUiThread(new Runnable() {
            public void run() {

            	 ConnectionProvider.runListener();

           }
       });
        ChatListener.getInstance().registerActivity(this);
        
    }
	
	public void notifyActivity(){
		try{
			
			runOnUiThread(new Runnable() {
	            public void run() {

	            	List<ChatEntry> chat = ChatListener.getInstance().getConversation(ChatListener.userOrGroupName);
	        		String conversation = "";
	        		for(ChatEntry entry : chat){
	        			conversation += entry.getMessage() + "\n";
	        		}
	        		
	        		TextView view = (TextView)findViewById(R.id.chatView);
	        		try{
	        			view.setText("");
	        			view.setText(conversation);
	        		}
	        		catch(Exception ex){
	        			String info = "";
	        		}

	           }
	       });
		}
		catch(Exception ex){
			String log = "";
		}
	    
		
	}
	
	
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(requestCode == 100){
			try{
				userId = data.getStringExtra("userId");
				String text = "Rozmowcy (wybrano " + userId + ")";
				Button buttonUsers = (Button)findViewById(R.id.users);
				buttonUsers.setText(userId);
			}
			catch(Exception ex){
				ex = null;
			}
			
			notifyActivity();
		}
	}
	
	private class WSMessageThread extends Thread{
		String to;
		String message;
		public WSMessageThread(String to, String message){
			this.to = to;
			this.message = message;
			
		}
            @Override
            public void run() {
                try {
                	ChatSender sender =ChatListener.isGroupChatSelected ? new ChatSenderGroup() : new ChatSenderUser();
                	sender.sendMessage(to, message);
                } catch (Exception e) {
                    e.printStackTrace();
                    e.printStackTrace();
                }
            }
	}
}
