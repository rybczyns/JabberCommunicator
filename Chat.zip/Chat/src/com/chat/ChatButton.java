package com.chat;

import com.chat.jabber.ChatListener;
import com.chat.jabber.ChatSenderGroup;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class ChatButton extends Button{

	private String userId;
	UserListActivity context;
	private boolean user;
	private boolean group;
	public ChatButton(UserListActivity context, String userId, boolean isUser, boolean isGroupChat) {
		super(context);
		this.userId = userId;
		addListener();
		this.context = context;
		this.user = isUser;
		this.group = isGroupChat;
	}
	
	void addListener(){
		setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	Intent i = new Intent(getContext().getApplicationContext(),ChatActivity.class);
            	
            	ChatListener.isGroupChatSelected = group;
            	ChatListener.userOrGroupName = userId;
            	i.putExtra("userId", userId);
            	//getContext().startActivity(i);
            	context.setResult(Activity.RESULT_OK, i);
            	context.finish();
            	
            	if(group){
            		new ChatSenderGroup().login(userId);
            	}
            }
        });

	}

}
