package com.chat.jabber;

import org.jivesoftware.smack.Chat;
import org.jivesoftware.smack.ChatManager;
import org.jivesoftware.smack.ChatManagerListener;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.XMPPConnection;

public class ConnectionProvider {
	private static XMPPConnection connection;
	
	public static XMPPConnection getConenction(){
		if(connection == null){
			ConnectionConfiguration config = new ConnectionConfiguration("10.0.2.2");
			connection = new XMPPConnection(config);
			
		}
		return connection;
	}
	
	public static void runListener(){
		ChatManager chatmanager = connection.getChatManager();
		
		chatmanager.addChatListener(new ChatManagerListener()
		  {
		    public void chatCreated(final Chat chat, final boolean createdLocally)
		    {
		      chat.addMessageListener(ChatListener.getInstance());
		    }
		  });
	}

}
