package com.chat.jabber;

public interface ChatSender {
	public void sendMessage(String to, String message);
	
	public void login(String to);
}
