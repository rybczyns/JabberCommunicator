package com.chat.jabber;

import org.jivesoftware.smack.XMPPException;

public class ChatSenderUser implements ChatSender{

	
	public void sendMessage(String to, String message){
		if(!ChatListener.getInstance().getChatMap().containsKey(to)){
			ChatListener.getInstance().createChat(to);
		}
		try {
			ChatListener.getInstance().getChatMap().get(to).sendMessage(message);
		} catch (XMPPException e) {
		}
	}

	@Override
	public void login(String to) {
		// TODO Auto-generated method stub
		
	}
}
