package com.chat.jabber;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jivesoftware.smack.Chat;
import org.jivesoftware.smack.MessageListener;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Message.Type;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smackx.muc.MultiUserChat;

import com.chat.ChatActivity;

public class ChatListener implements MessageListener, PacketListener{

	private Map<String,Chat> chatMap;
	private Map<String,MultiUserChat> groupChatMap;
	private Map<String,List<ChatEntry>> userChat;
	private Map<String,List<ChatEntry>> groupChat;
	
	public static boolean isGroupChatSelected;
	public static String userOrGroupName;
	
	private static ChatListener instance;
	
	private static ChatActivity activity;
	
	public static ChatListener getInstance(){
		if(instance == null){
			instance = new ChatListener();
		}
		return instance;
	}
	
	
	public static void registerActivity(ChatActivity activity){
		ChatListener.activity = activity;
	}
	
	public ChatListener(){
		setChatMap(new HashMap<String, Chat>());
		setUserChat(new HashMap<String, List<ChatEntry>>());
		setGroupChat(new HashMap<String, List<ChatEntry>>());
		setGroupChatMap(new HashMap<String, MultiUserChat>());
	}

	private void setChatMap(HashMap<String, Chat> hashMap) {
		this.chatMap = hashMap;
	}

	@Override
	public void processMessage(Chat chat, Message message) {
		String userName = parseUserName(message.getFrom());
		String text = message.getBody();
		
		if(!userChat.containsKey(userName)){
			userChat.put(userName, new ArrayList<ChatEntry>());
		}
		userChat.get(userName).add(new ChatEntry(userName,text));
		activity.notifyActivity();
		
	}

	private static String parseUserName(String userName){
		return userName.substring(0, userName.indexOf("/"));
	}
	
	public Map<String,Chat> getChatMap() {
		return chatMap;
	}

	public void createChat(String to) {
		Chat chat = ConnectionProvider.getConenction().getChatManager().createChat(to, this);
		chatMap.put(to, chat);
	}

	public List<ChatEntry> getConversation(String userName){
		if(isGroupChatSelected){
			if(!groupChat.containsKey(userOrGroupName)){
				groupChat.put(userOrGroupName, new ArrayList<ChatEntry>());
			}
		
			return groupChat.get(userOrGroupName);
		}
		else{
			if(!userChat.containsKey(userName)){
				userChat.put(userName, new ArrayList<ChatEntry>());
			}
		
			return userChat.get(userName);
		}
	}
	
	public Map<String,List<ChatEntry>> getUserChat() {
		return userChat;
	}

	public void setUserChat(Map<String,List<ChatEntry>> userChat) {
		this.userChat = userChat;
	}


	@Override
	public void processPacket(Packet packet) {
		if(isGroupChatSelected){
			Message m = (Message)packet;
			if(m.getType() == Type.groupchat){
				m.getBodies().iterator().next().getMessage();
				String from = m.getFrom();
				String texSt = m.getBodies().iterator().next().getMessage();
				if(!groupChat.containsKey(userOrGroupName))
				{
					groupChat.put(userOrGroupName, new ArrayList<ChatEntry>());
				}
				
				int index = from.indexOf("/");
				from = from.substring(index, from.length());
				
				groupChat.get(userOrGroupName).add(new ChatEntry(userOrGroupName,from + ":" + texSt));
				
				
				
				
				
				
				activity.notifyActivity();
			}
		}
		
	}


	public Map<String,List<ChatEntry>> getGroupChat() {
		return groupChat;
	}


	public void setGroupChat(Map<String,List<ChatEntry>> groupChat) {
		this.groupChat = groupChat;
	}


	public Map<String,MultiUserChat> getGroupChatMap() {
		return groupChatMap;
	}


	public void setGroupChatMap(Map<String,MultiUserChat> groupChatMap) {
		this.groupChatMap = groupChatMap;
	}
	
	
}
