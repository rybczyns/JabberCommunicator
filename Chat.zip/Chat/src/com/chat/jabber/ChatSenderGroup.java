package com.chat.jabber;

import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smackx.muc.MultiUserChat;

import com.chat.webservice.UsersWebService;

public class ChatSenderGroup implements ChatSender{

	@Override
	public void sendMessage(String to, String message) {
		try{
			if(!ChatListener.getInstance().getGroupChatMap().containsKey(to)){
				MultiUserChat chat = new MultiUserChat(ConnectionProvider.getConenction(), to);
				chat.addMessageListener(ChatListener.getInstance());
				ChatListener.getInstance().getGroupChatMap().put(to, chat);
			}
			if(!ChatListener.getInstance().getGroupChatMap().get(to).isJoined()){
				ChatListener.getInstance().getGroupChatMap().get(to).join(ConnectionProvider.getConenction().getUser());
			}
			ChatListener.getInstance().getGroupChatMap().get(to).sendMessage(message);
			String user = ConnectionProvider.getConenction().getUser();
			new UsersWebService().sendMessage(user, to, message);
		}
		catch(Throwable t){
			String log = "";
		}
	}

	@Override
	public void login(String to) {
		if(!ChatListener.getInstance().getGroupChatMap().containsKey(to)){
			MultiUserChat chat = new MultiUserChat(ConnectionProvider.getConenction(), to);
			chat.addMessageListener(ChatListener.getInstance());
			ChatListener.getInstance().getGroupChatMap().put(to, chat);
		}
		if(!ChatListener.getInstance().getGroupChatMap().get(to).isJoined()){
			try {
				String user = ConnectionProvider.getConenction().getUser();
				ChatListener.getInstance().getGroupChatMap().get(to).join(user);
			} catch (XMPPException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
