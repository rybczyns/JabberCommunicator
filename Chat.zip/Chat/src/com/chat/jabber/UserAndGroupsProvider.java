package com.chat.jabber;

import java.util.ArrayList;
import java.util.List;

import org.jivesoftware.smack.Connection;
import org.jivesoftware.smack.XMPPException;

public class UserAndGroupsProvider {
	public static void populateUsersAndGroups(Connection connection){
		try {
			connection.getRoster().createEntry("user2@example.com", "user2@example.com", new String[]{"Home"});
			
		} catch (XMPPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static String serverName = "NazwaSerwera";
	public static String hostName = "@conference." + serverName;
	
	
	public static List<String> users;
	public static List<String> groups;
	
	public static List<String> getChatRooms(){
		List<String> groupChats = new ArrayList<String>();
		
		groupChats.add("magisterka" + hostName);
		groupChats.add("projekty" + hostName);
		groupChats.add("rozne" + hostName);
		
		return groupChats;
	}
}
