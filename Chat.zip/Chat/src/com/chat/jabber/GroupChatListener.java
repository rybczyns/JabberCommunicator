package com.chat.jabber;

public class GroupChatListener {

}
