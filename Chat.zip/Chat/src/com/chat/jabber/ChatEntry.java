package com.chat.jabber;

public class ChatEntry {
	private String user;
	private String message;
	public ChatEntry(String userName, String text) {
		this.user = userName;
		this.message = text;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
