package com.chat;

import java.util.List;

import com.chat.jabber.UserAndGroupsProvider;
import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;

public class UserListActivity extends Activity{
	 @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        
	        setContentView(R.layout.activity_users);
	       // getUsers(this);
	        LinearLayout layout = (LinearLayout) findViewById(R.id.userListId);
	        layout.setOrientation(LinearLayout.VERTICAL);  //Can also be done in xml by android:orientation="vertical"
	        List<String> users = UserAndGroupsProvider.users;
        	List<String> groups = UserAndGroupsProvider.groups;
        	
        	int id = 1;
        	 for (String user : users) {
 	            LinearLayout row = new LinearLayout(this);
 	            row.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
 	            	Button btnTag = new ChatButton(this,user,true,false);
 	                btnTag.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
 	                btnTag.setText("Select " + user);
 	                btnTag.setId(id++);
 	                row.addView(btnTag);
 	            layout.addView(row);
 	        }
 	        for(String group : groups){
 	        	LinearLayout row = new LinearLayout(this);
 	        	Button btn = new ChatButton(this, group, false, true);
 	        	btn.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
 	        	btn.setText("Select " + group);
 	        	btn.setId(id++);
                 row.addView(btn);
             layout.addView(row);
	    }
	 }
}
