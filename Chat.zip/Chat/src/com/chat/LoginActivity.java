package com.chat;

import java.util.List;

import org.jivesoftware.smack.Connection;
import com.chat.jabber.ConnectionProvider;
import com.chat.jabber.UserAndGroupsProvider;
import com.chat.webservice.UsersWebService;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        
        setContentView(R.layout.activity_login);
        Button button =  (Button )findViewById(R.id.sendMessageButton);
        
        //nazwa
        UserAndGroupsProvider.serverName = "NazwaSerwera";
        
        ((TextView)findViewById(R.id.loginText)).setText("user1@"+ UserAndGroupsProvider.serverName);
        ((TextView)findViewById(R.id.conversationText)).setText("123");
        ((TextView)findViewById(R.id.editText1)).setText(UserAndGroupsProvider.serverName);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	String login = ((TextView)findViewById(R.id.loginText)).getText().toString();
            	String password = ((TextView)findViewById(R.id.conversationText)).getText().toString();
            	connectToServer(login,password);
            }
        });

        AsyncCallWS task = new AsyncCallWS();
        task.execute();
    }

    @Override
    protected void onActivityResult(int requestCode,
                                     int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
    }

    private void connectToServer(final String login, final String password){
    	Thread thread = new Thread(new Runnable(){
            @Override
            public void run() {
                try {
                	try {
            			ConnectionProvider.getConenction().connect();
            			Connection connection = ConnectionProvider.getConenction();
            			if(!connection.isAuthenticated()){
	            			connection.login(login, password);
	            			boolean isAuthenticated = ConnectionProvider.getConenction().isAuthenticated();
	            			
	            			UserAndGroupsProvider.populateUsersAndGroups(connection);
	            			if(!isAuthenticated){
	            				throw new RuntimeException();
	            			}
	            			else{
	            				Intent i = new Intent(getApplicationContext(),ChatActivity.class);
	                        	startActivity(i);
	            			}
            			}
            		} catch (Throwable e1) {
            			e1.printStackTrace();
            		}
                } catch (Exception e) {
                    e.printStackTrace();
                    e.printStackTrace();
                }
            }
        });
    	thread.start();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.login, menu);
        return true;
    }
    
    
    
}
