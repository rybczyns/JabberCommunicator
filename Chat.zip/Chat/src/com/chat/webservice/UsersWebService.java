package com.chat.webservice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class UsersWebService {

	//private static final String SOAP_ACTION = "http://ws.android.com/hello";
	private static final String SOAP_ACTION = "http://users/";
	private static final String NAMESPACE = "http://users/";
	private static final String URL = "http://10.0.2.2:8080/UserProvider/UserProviderService?WSDL";

	private static final String USERS = "getUsers";
	private static final String ROOMS = "getPublicRooms";
	
	private static final String SEND_MESSAGE = "sendMessage";
	String str;
	public List<String> getUsers() {
		String result = involeMethod(USERS, prepareRequest(USERS, new ArrayList<String>(), new ArrayList<String>()));
		return transformToList(result);

	}
	
	public void sendMessage(String user, String room, String message){
		String[] params = {"arg0","arg1","arg2"};
		String[] values = {user,room,message};
		involeMethod(SEND_MESSAGE, prepareRequest(SEND_MESSAGE, Arrays.asList(params), Arrays.asList(values)));
	}
	
	private List<String> transformToList(String s){
		String[] items = s.split(";");
		return Arrays.asList(items);
	}
	
	private String involeMethod(String methodName, SoapObject request){
		try {
			
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
					SoapEnvelope.VER11);
			envelope.setOutputSoapObject(request);

			HttpTransportSE ht = new HttpTransportSE(URL);
			
			ht.call(SOAP_ACTION + methodName, envelope);
			final SoapPrimitive response = (SoapPrimitive) envelope
					.getResponse();
			if(response != null){
			return response.toString();
			}else{
				return "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	private SoapObject prepareRequest(String methodName, List<String> params, List<String> values){
		SoapObject request = new SoapObject(NAMESPACE, methodName);
		
		Iterator<String> valueIt = values.iterator();
		for(String p : params){
			request.addProperty(p, valueIt.next());
		}
		
		return request;
	}

	public List<String> getRooms() {

		String result = involeMethod(ROOMS, prepareRequest(ROOMS, new ArrayList<String>(), new ArrayList<String>()));
		return transformToList(result);

	}
	
}